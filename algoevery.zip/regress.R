#Perform the nonlinear regression
